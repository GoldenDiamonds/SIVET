<script>
   $("#btnLimpiar").click(function(event) {
	   $("#formEjemplo")[0].reset();
   });
</script>