<?php 
	include_once 'conexionDB.php';

$Correo = $_POST['Correo'];
$Contraseña = $_POST['Contraseña'];

		$sqlA=mysqli_query($mysqli,"SELECT * FROM usuarios WHERE Correo='$Correo'");
			if($adm=mysqli_fetch_assoc($sqlA)){
				if($Contraseña==$adm['ConAdmin']){
					$_SESSION['Id_User']=$adm['Id_User'];
					$_SESSION['Empresa']=$adm['Empresa'];
					$_SESSION['TipoUsuario']=$adm['TipoUsuario'];
					//echo '<script>alert("BIENVENIDO ADMINISTRADOR")</script>';
					echo "<script>location.href='PanelAdmin.php'</script>";
				}
			}

			$sql=mysqli_query($mysqli,"SELECT * FROM usuarios WHERE Correo='$Correo'");
			if($C=mysqli_fetch_assoc($sql)){
				if($Contraseña==$C['Password']){
					$_SESSION['Id_User']=$C['Id_User'];
					$_SESSION['Empresa']=$C['Empresa'];
					$_SESSION['TipoUsuario']=$C['TipoUsuario'];
					//echo '<script>alert("BIENVENIDO")</script> ';
					header("Location: PanelUsuario.php");
				}else{
					echo '<script>alert("CONTRASEÑA INCORRECTA")</script> ';
				
					echo "<script>location.href='Log In.html'</script>";
				}
			}else{
				
				echo '<script>alert("EL USUARIO NO EXISTE, PORFAVOR REGISTRESE PARA PODER INGRESAR")</script> ';
				
				echo "<script>location.href='Log In.html'</script>";	

			} 

 ?>