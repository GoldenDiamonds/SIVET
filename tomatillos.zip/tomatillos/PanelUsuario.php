<!DOCTYPE html>
<html>
<head>
	<title>PanelUsuario</title>
</head>
<body>
	<h1>
		Bienvenido Usuario
	</h1>

</body>
</html>