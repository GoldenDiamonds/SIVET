<!DOCTYPE html>
<html>
<head>
	<title>Administrador</title>
</head>
<body>
	<h1>
		Bienvenido Administrador
	</h1>

</body>
</html>