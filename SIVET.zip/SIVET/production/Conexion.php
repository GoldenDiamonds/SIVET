<?php
	class Conexion {
		public function conectar(){

			//Localhost, usuario, contrasenia, BD, puertoMySQL=3306.
         $mysqli = mysqli_connect("localhost", "root", "", "sisve");
			if ($mysqli->connect_errno) 
				header('Location: 404.html');

				$mysqli->set_charset('utf8');
				return $mysqli;
		}
	}


	#$Conexion = new Conexion();
	#$Conexion->conectar();

?>