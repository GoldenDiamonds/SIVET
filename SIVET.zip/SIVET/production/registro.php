<?php
	
	require 'Conexion.php';
	class Registrarse extends Conexion{

		function __construct(){
        	$this->mysqli = parent::conectar();
      	}

		public function Registrarse($a, $b){
	      if( !($sentencia = $this->mysqli->prepare("INSERT INTO usuario (id, usuario, contrasenia) VALUES (default, ?, ?)") ) ){
	        echo "Falló la preparación: (" . $this->mysqli->errno . ")" . $this->mysqli->error;
	      }else{
	        if( !$sentencia->bind_param('ss', $a, $b)){
	          echo "Falló la vinculación de parámetros: (" . $this->mysqli->errno . ")" . $this->mysqli->error;
	        }else{
	          if( !$sentencia->execute() )
	          		echo "Falló la ejecución: (" . $sentencia->errno . ") " . $sentencia->error;

	          	else
	          		#echo "insertado";
	          		return true;
	        }
	      }
    	}

     public function listartodos(){
         $resultado = $this->mysqli->query("SELECT * FROM usuario where estatus = 1");
         $resultado->data_seek(0);
         
         while( $fila = $resultado->fetch_assoc() ){
            $data[] = $fila;
         }
         
         return $data;
      }

     public function buscaIdRegistro($a){
         $resultado = $this->mysqli->query("SELECT * FROM usuario where id = $a");
         $resultado->data_seek(0);
         
         while( $fila = $resultado->fetch_assoc() ){
            $data[] = $fila;
         }
         
         return $data;
      }

      public function actualizarRegistro($id){
      	if (!($sentencia = $this->mysqli->prepare("UPDATE usuario SET usuario = ?, contrasenia= ? WHERE id = ?")))
      		echo "Falló la preparación: (" . $this->mysqli->errno . ")" . $this->mysqli->error;
      	elseif (!$sentencia->bind_param('ssi', $_POST['usuario'], $_POST['contrasenia'], $id)) 
      			echo "Falló la vinculación de parámetros: (" . $sentencia->errno .")" . $sentencia->error;
      	elseif (!$sentencia->execute()) 
      			echo "Falló la ejecución: (". $sentencia->errno .")" . $sentencia->error;
      	else
      			return true;
      			
      		
      	
      }

      public function eliminarRegistro($id){
        //echo "matricula".$matricula;
        if (!($sentencia = $this->mysqli->prepare("DELETE FROM usuario WHERE id = ?")))
          echo "Falló la preparación: (" . $this->mysqli->errno . ")" . $this->mysqli->error;
        elseif (!$sentencia->bind_param('s', $id)) 
            echo "Falló la vinculación de parámetros: (" . $sentencia->errno .")" . $sentencia->error;
        elseif (!$sentencia->execute()) 
            echo "Falló la ejecución: (". $sentencia->errno .")" . $sentencia->error;
        else
            return true;
            
          
        
      }

}
