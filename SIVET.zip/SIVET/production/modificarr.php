<?php

   	# conectare la base de datos
    $con=@mysqli_connect('localhost', 'root', '', 'sisve');
    if(!$con){
        die("imposible conectarse: ".mysqli_error($con));
    }
    if (@mysqli_connect_errno()) {
        die("Connect failed: ".mysqli_connect_errno()." : ". mysqli_connect_error());
    }
	/*Inicia validacion del lado del servidor*/
	if (empty($_POST['id'])) {
           $errors[] = "Id vacío";
        } else if (empty($_POST['usuario'])){
			$errors[] = "Usuario vacío";
		} else if (empty($_POST['contrasenia'])){
			$errors[] = "Contraseña vacío";
		}else if (empty($_POST['correo'])){
			$errors[] ="correo";
		}  else if (
			!empty($_POST['id']) &&
			!empty($_POST['usuario']) &&
			!empty($_POST['contrasenia'])&&
			!empty($_POST['correo'])

			
		){


		// escaping, additionally removing everything that could be (html/javascript-) code
		$usuario=mysqli_real_escape_string($con,(strip_tags($_POST["usuario"],ENT_QUOTES)));
		$contrasenia=mysqli_real_escape_string($con,(strip_tags($_POST["contrasenia"],ENT_QUOTES)));
		$correo=mysqli_real_escape_string($con,(strip_tags($_POST["correo"],ENT_QUOTES)));

		$id=intval($_POST['id']);

		$sql="UPDATE usuarios SET  usuario='".$usuario."',
		contrasenia='".$contrasenia."' , correo='".$correo."'	WHERE id ='".$id."'";
		$query_update = mysqli_query($con, $sql);
			if ($query_update){
				$messages[] = "Los datos han sido actualizados satisfactoriamente.";
			} else{
				$errors []= "Lo siento algo ha salido mal intenta nuevamente.".mysqli_error($con);
			}
		} else {
			$errors []= "Error desconocido.";
		}
		
		if (isset($errors)){
			
			?>
			<div class="alert alert-danger" role="alert">
				<button type="button" class="close" data-dismiss="alert">&times;</button>
					<strong>Error!</strong> 
					<?php
						foreach ($errors as $error) {
								echo $error;
							}
						?>
			</div>
			<?php
			}
			if (isset($messages)){
				
				?>
				<div class="alert alert-success" role="alert">
						<button type="button" class="close" data-dismiss="alert">&times;</button>
						<strong>¡Bien hecho!</strong>
						<?php
							foreach ($messages as $message) {
									echo $message;
								}
							?>
				</div>
				<?php
			}

?>	