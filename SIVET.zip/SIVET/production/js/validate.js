
<html>
<body>

<?php
// process form
$link = mysqli_connect("localhost", "root");
mysqli_select_db("sisve",$db);
$sql = "INSERT INTO sisve (nombre, apellidos, usuario, contrasenia, conf_contrasenia, correo) " +
  "VALUES ('$nombre', '$apellidos', '$usuario', '$contrasenia', '$conf_contrasenia', '$correo')";
$result = mysqli_query($sql);
echo "¡Gracias! Hemos recibido sus datos.\n";


?> 
  
   <form method="post" action="add_reg.php3">
   Nombre   :<input type="Text" name="nombre"><br>
   Dirección:<input type="Text" name="direccion"><br>
   Teléfono :<input type="Text" name="telefono"><br>
   E-mail   :<input type="Text" name="email"><br>
   <input type="Submit" name="enviar" value="Aceptar información">
   </form> 
  
<?php 
} //end if 
?> 

</body>
</html> 
</body>
</html>