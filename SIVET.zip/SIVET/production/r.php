<?php
	require 'usuario.php';
	$obj = new Usuario();
	$datos = $obj->listartodos();

?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>app_movil</title>
  <link rel="shortcut icon" href="favicon.ico">
  <link rel="stylesheet" href="css/themes/default/jquery.mobile-1.4.5.min.css">
  <link rel="stylesheet" href="_assets/css/jqm-demos.css">
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,700">
  <script src="js/jquery.js"></script>
  <script src="_assets/js/index.js"></script>
  <script src="js/jquery.mobile-1.4.5.min.js"></script>
</head>
<body>
<div data-role="page">
	<div data-role="header">
		<h1>Resultados</h1>
	</div>
	<div data-role="content">
		<?php if(sizeof($datos) > 0): ?>
			<table data-role="table" data-mode="columntoggle" class="ui-responsive" id="myTable">
      <thead>
        <tr>
          <th data-priority="6">Id</th>
          <th>Matricula</th>
          <th data-priority="1">Usuario</th>
          <th data-priority="2">Contrasenia</th>
          <th data-priority="3">Correo</th>
          <!--th data-priority="5">Status</th-->
        </tr>
      </thead>
      <tbody>
      	<?php foreach ($datos as $row): ?>
      		<tr>
      			<td>
      				<?php echo $row['id']; ?>
      			</td>
      			<td>
      				<?php echo $row['usuario']; ?>
      			</td>
      			<td>
      				<?php echo $row['contrasenia']; ?>
      			</td>
      			<td>
      				<?php echo $row['correo'] ?>
      			</td>
      			<td>
      				<?php echo $row['estatus']; ?>
      			</td>
            <td>
              <a href="../controller/editar.php?matricula=<?php echo $row['matricula']; ?>">Editar</a>
            </td>
             <td>
              <a href="../controller/eliminar.php?matricula=<?php echo $row['matricula']; ?>">Eliminar</a>
            </td>
      		</tr>     	
      		<?php endforeach; ?>
      </tbody>
      </table>
	<?php endif; ?>
  <form class="ut" action="../view/index.html">
      <br>
      <button type="submit">Cerrar Sesión</button>
  </form>
	</div>
	<div data-role="footer">
		<h1>Footer</h1>
	</div>
</div>
</body>
</html>