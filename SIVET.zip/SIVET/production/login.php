
<?php

session_start();
echo $_SESSION['usuario']=$_REQUEST['usuario']."<b>";

?>


            <?php
            ini_set('display_errors','off');
            ini_set('display_startup_errors', 'off');
            error_reporting(0);
            
            function Conectarse()


             {
              if (!($link=mysql_connect("localhost","root", "", "sisve")))
               {
                echo "Error conectando a la base de datos.";

               }
               if (!mysql_select_db("sisve",$link))
                 {
                  echo "Error selecionando la base datos.";
                  exit();
               }
                 return $link;
             }
             $con = Conectarse();

             $usuario = $_REQUEST["usuario"];
              $contrasenia = $_REQUEST["contrasenia"];

             $query = "SELECT COUNT(*) AS Num FROM usuarios where usuario ='".$usuario."'AND contrasenia ='".$contrasenia."'";
             

             //$q = mysql_query($query,$con);
             $q = mysql_query($query);
            //echo $query  . mysql_result($q, 0);

             try {
              //$re= mysql_result($q,0);
              if (mysql_result($q,0) == 1)

                 {//$result = mysql_result($q,O);

      
    echo'<script type="text/javascript">
                        alert("Datos ingresados correctamente");
                        window.location="indexAdmin.php"
                        </script>';
      

                 //header ("location: indexAdmin.php");



                 }else

              echo'<script type="text/javascript">
                        alert("Datos incorrectos");
                        window.location="formulario.php"
                        </script>';
   
              //echo '<script language="javascript">alert("Las contraseñas no coinciden");</script>'; 
              //header('Location:../view/login.php');
  
                    
                 //header("location: index.html"); 
                

                 
                   
                }catch(Exception $error){}
             mysql_close($con);


              /*public function agregaUsuario($usuario, $contrasenia){
 
        //Selecciona el correo ingresado para validarlo, en la variable valida
        //está el resultado de la consulta
 
        $nuevo_correo = "select usuario from usuario where usuario='$usuario'";
        $valida = $this->mysqli->query($nuevo_correo);
 
        //Como correo es UNIQUE si valida tiene más de un resultado,
        //el correo ya estaba en la base de datos
        if($valida->num_rows > 0)
        {
              echo'<script type="text/javascript">
                alert("Error al registrar! - usuario Duplicado - Ingresa otro");
                window.location="e.php"
                </script>';
        }
        //Sino hubo correo repetido
        else
        {
            //Inserta en la BD
            $q = "INSERT INTO usuarios (nombre, apellidos, correo, password) VALUES ('$nombre','$apellidos', '$mail', '$contras'); ";
 
            $result = $this->mysqli->query($q);
            if($result){ //Si resultado es true, se agregó correctamente
                    echo'<script type="text/javascript">
                        alert("Agregado Exitosamente");
                        window.location="index.php"
                        </script>';
            }
            else{ //Si hubo error al insertar, se avisa
                echo'<script type="text/javascript">
                     alert("Algo fallo");
                     window.location="e.php"
                     </script>';
 
            }
        }
    }
}*/

            ?>


?>







