<!DOCTYPE html<html>
<head>
	<title></title>
</head>
<body>
	<?php
		require 'usuario.php';
		$obj = new Usuario();
		$bandera = $obj->registrarUsuario( $_REQUEST['usuario'],  $_REQUEST['contrasenia'], $_REQUEST['correo']);

		if ($bandera) {
			header('location:r.php');
		}
	?>

</body>
</html>