<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php
		require 'registro.php';
		$obj = new Registrarse();
		$bandera = $obj->eliminarRegistro( $_REQUEST['id']);

		if ($bandera) {
			header('location:registrarse.php');
		}
	?>

</body>
</html>