<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php
	require 'registro.php';
	$obj = new Registrarse();
	$bandera = $obj->actualizarRegistro($_POST['id']);

	if ($bandera) {
		header('location:registrarse.php');
	}
?>
</body>
</html>