<form id="actualidarDatos">
<div class="modal fade" id="dataUpdate" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="exampleModalLabel">Modificar:</h4>
      </div>
      <div class="modal-body">
      <div id="datos_ajax"></div>
          <!--div class="form-group">
            <label for="codigo" class="control-label">Código:</label>
            <input type="text" class="form-control" id="codigo" name="codigo" required maxlength="2">
      <input type="hidden" class="form-control" id="id" name="id">
          </div-->
      
      <div class="form-group">
            <label for="" class="control-label">Usuario:</label>
            <input type="text" class="form-control"  name="usuario" required maxlength="40">
            <input type="hidden" class="form-control" id="id" name="id">

          </div>
      <div class="form-group">
            <label for="" class="control-label">Contraseña:</label>
            <input type="password" class="form-control" name="contrasenia" required maxlength="30"> 
          </div>
      <div class="form-group">
            <label for="" class="control-label">Correo:</label>
            <input type="text" class="form-control"  name="correo" required maxlength="30"> 
      </div>
     
          
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
        <button type="submit" class="btn btn-primary">Actualizar datos</button>
      </div>
    </div>
  </div>
</div>
</form>