<?
include 'Conexion.php'
    // Primero comprobamos que ningún campo esté vacío y que todos los campos existan.
    if(isset($_POST['usuario']) && !empty($_POST['usuario']) &&
    isset($_POST['contrasenia']) && !empty($_POST['contrasenia']) &&
    isset ($_POST['correo']) && !empty($_POST['correo'])) {

        // Si entramos es que todo se ha realizado correctamente
        $link = mysqli_connect ($dbhost, $dbusername, $dbuserpass);
        mysqli_select_db($dbname,$link);

        // Con esta sentencia SQL insertaremos los datos en la base de datos
        mysqli_query("INSERT INTO usuarios (usuario,contrasenia,correo)
        VALUES ('{$_POST['usuario']}','{$_POST['contrasenia']}','{$_POST['correo']}')",$link);

        // Ahora comprobaremos que todo ha ido correctamente
        $my_error = mysqli_error($link);

        if(!empty($my_error)) {

            echo "Ha habido un error al insertar los valores. $my_error";

        } else {

         

            echo "Los datos han sido introducidos satisfactoriamente";



        

    } else {

        echo "Error, no ha introducido todos los datos";

    }

    }

?>