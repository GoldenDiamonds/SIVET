
<!DOCTYPE html>
<html dir="ltr" lang="en-US">
<head>

	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<meta name="author" content="SemiColonWeb" />

	<!-- Stylesheets
	============================================= -->
	<link href="https://fonts.googleapis.com/css?family=Lato:300,400,400i,700|Raleway:300,400,500,600,700|Crete+Round:400i" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" href="http://canvashtml-cdn.semicolonweb.com/v5/css/bootstrap.css" type="text/css" />
	<link rel="stylesheet" href="http://canvashtml-cdn.semicolonweb.com/v5/style.css" type="text/css" />
	<link rel="stylesheet" href="http://canvashtml-cdn.semicolonweb.com/v5/css/swiper.css" type="text/css" />
	<link rel="stylesheet" href="http://canvashtml-cdn.semicolonweb.com/v5/css/dark.css" type="text/css" />
	<link rel="stylesheet" href="http://canvashtml-cdn.semicolonweb.com/v5/css/font-icons.css" type="text/css" />
	<link rel="stylesheet" href="http://canvashtml-cdn.semicolonweb.com/v5/css/animate.css" type="text/css" />
	<link rel="stylesheet" href="http://canvashtml-cdn.semicolonweb.com/v5/css/magnific-popup.css" type="text/css" />
	<link rel="stylesheet" href="http://canvashtml-cdn.semicolonweb.com/v5/css/responsive.css" type="text/css" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<script src="js/jquery.validate.js" type="text/javascript"></script>


	<!-- Document Title





<!-Content============================================= -->
		<section id="content">

			<div class="content-wrap">

				<div class="container clearfix">

					<div class="tabs divcenter nobottommargin clearfix" id="tab-login-register" style="max-width: 500px;">

						<ul class="tab-nav tab-nav2 center clearfix">
							<li class="inline-block"><a href="#tab-login">Login</a></li>
						

						</ul>

						<div class="tab-container">

							<div class="tab-content clearfix" id="tab-login">
								<div class="card nobottommargin">
									<div class="card-body" style="padding: 40px;">
										<form id="login-form" name="login-form" class="nobottommargin" action="login.php" method="post">

											<h3>Login</h3>

											<div class="col_full">
												<label for="login-form-username">Usuario:</label>
												<input type="text" id="login-form-username" name="usuario" value="" class="form-control"  />
											</div>

											<div class="col_full">
												<label for="login-form-password">Contraseña:</label>
												<input type="password" id="login-form-password" name="contrasenia" value="" class="form-control" />
											</div>

											<div class="col_full nobottommargin">
												<button class="button button-3d button-black nomargin" id="login-form-submit" name="login-form-submit" value="login">Ingresar</button>
												<a href="#" class="fright">¿Olvidaste tu contraseña?</a>
											</div>
											<br>


											<div class="col_full nobottommargin">
												<button class="button button-3d button-black nomargin" id="register-form-submit" name="register-form-submit" value="register"><a href="index.html">Regresar a inicio</button></a>
											</div>

										</form>
									</div>
								</div>
							</div>
							</div>

							

						</div>

					</div>

				</div>

			</div>
			</div>

		</section><!-- #content end -->
			

	<!-- External JavaScripts
	============================================= -->
	<script src="http://canvashtml-cdn.semicolonweb.com/v5/js/jquery.js"></script>
	<script src="http://canvashtml-cdn.semicolonweb.com/v5/js/plugins.js"></script>

	<!-- Footer Scripts
	============================================= -->
	<script src="http://canvashtml-cdn.semicolonweb.com/v5/js/functions.js"></script>

</body>
</html>