<!DOCTYPE html<html>
<head>
	<title></title>
</head>
<body>
	<?php
		require 'registro.php';
		$obj = new Registrarse();
		$bandera = $obj->Registrarse($_POST['usuario'],  $_POST['contrasenia']);

		if ($bandera) {
			//header('location: ../vista/Registros.php');
			echo "<script>alert(\"REGISTRO EXITOSO.\");window.location='registrarse.php';</script>";
		}
	?>

</body>
</html>