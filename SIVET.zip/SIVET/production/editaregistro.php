<?php
require 'registro.php';
$obj = new Registrarse();
$datos = $obj->buscaIdRegistro($_GET['id']);
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>EDITAR REGISTRO</title>
  <link rel="shortcut icon" href="favicon.ico">
  <link rel="stylesheet" href="css/themes/default/jquery.mobile-1.4.5.min.css">
  <link rel="stylesheet" href="_assets/css/jqm-demos.css">
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,700">
  <script src="js/jquery.js"></script>
  <script src="_assets/js/index.js"></script>
  <script src="js/jquery.mobile-1.4.5.min.js"></script>
</head>
<body>
<div data-role="page">
	<div data-role="header">
		<h1>RESULTADOS DE LOS REGISTROS</h1>
	</div>
	<div data-role="content">
		<?php if(sizeof($datos) > 0): ?>
			<form action="actualizaresgistro.php" method="post">
			<table data-role="table" class="ui-reponsive" id="myTable">
			<thead>
				<tr>
					<th>ID</th>
					<th data-priority="1">Usuario</th>
					<th data-priority="2">Contraseña</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ($datos as $row): ?>
					<tr>
						<td>
						<div data-role="fieldcontain"  data-theme="b">
							<?php echo $row['id']; ?>
						</div>
						</td>
						<td>
						<div data-role="fieldcontain"  data-theme="b">
							<label for="usuario"></label>
							<input autofocus="true" type="text" name="usuario" value="<?php echo $row['usuario']; ?>">
						</div>
						</td>
						<td>
						<div data-role="fieldcontain"  data-theme="b">
							<label for="contrasenia"></label>
							<input type="password" name="contrasenia" value="<?php echo $row['contrasenia']; ?>">
						</div>
						</td>
						<td>
						
						</td>
						<td>
						<div data-role="fieldcontain"  data-theme="b">
							
							<input type="hidden" name="id" value="<?php echo $_GET['id']; ?>">
						</div>
						<input type="submit" name="Guardar" value="Guardar">
						</td>
						
					</tr>
				<?php endforeach; ?>
			</tbody>	
			</table>
		<?php endif; ?>
			</form>
	</div>
	<div data-role="footer">
		<h1>Footer</h1>
	</div>
</div>
</body>
</html>